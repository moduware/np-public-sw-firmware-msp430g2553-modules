/*
 * t_my_app.h
 *
 *  Created on: 2015-12-16
 *      Author: coody
 */

#ifndef T_MY_APP_H_
#define T_MY_APP_H_

void my_function_CMD_2700(unsigned char*pData, unsigned char len);
void my_function_CMD_2702(unsigned char*pData, unsigned char len);
void my_function_CMD_2704(unsigned char*pData, unsigned char len);
void my_function_CMD_2706(unsigned char*pData, unsigned char len);

#endif /* T_MY_APP_H_ */
