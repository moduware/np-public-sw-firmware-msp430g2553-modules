/*
 * np_module_mdk_v1.h
 *
 *  Created on: 2015-12-8
 *      Author: coody
 */

#ifndef NP_MODULE_MDK_V1_H_
#define NP_MODULE_MDK_V1_H_

#define MDK_REGISTER_SUCCESS	0x00
#define MDK_REGISTER_FAILD		0x01

//C++
typedef void (*my_VOID_UCUC)(unsigned char*, unsigned char);

/*MDK_REGISTER_CMD my_cmd_func_table[];
 *If module app set LPM4 mode,before the function on "my_cmd_func_table" is called, the mdk will wake up lpm4 once. Next loop will enter lpm4 again.
 */
typedef struct {
	unsigned short 	command;
	my_VOID_UCUC	function;
} MDK_REGISTER_CMD;

#ifdef __cplusplus
	extern "C" {
#endif

typedef enum{
	LPM_NONE = 0x00,
	LPM_0    = 0x01,
	LPM_1    = 0x02,	//unused
	LPM_2    = 0x04,	//unused
	LPM_3    = 0x08,	//unused
	LPM_4    = 0x10
}E_LPM;

inline void delay(unsigned int x) {while (x--) __delay_cycles(16000);}

void np_api_setup();
void np_api_loop();
void np_api_start();
void np_api_stop();
void np_api_download();
void np_api_poweroff();
void np_api_enter_lpm4_work();	//lpm4 function unopened, not using it
void np_api_exit_lpm4_work();	//lpm4 function unopened, not using it

/*
 * Description: API to set app firmware version
 * Parameter: null
 * Return: null
 *
 * Author: Coody.Liu
 *
 * Copyright: NexPack.Ltd
 */
void np_api_set_app_version(unsigned char HV, unsigned  char MV, unsigned char LV);
/*
 * Description: API to register developer's own Command for their module
 * Parameter: null
 * Return: null
 *
 * Author: Coody.Liu
 *
 * Copyright: NexPack.Ltd
 */
unsigned char np_api_register(MDK_REGISTER_CMD* cmd_func_table, unsigned char num);

/*
 * Description: API to upload data to Phone
 * Parameter: null
 * Return: null
 *
 * Author: Coody.Liu
 *
 * Copyright: NexPack.Ltd
 */
unsigned char np_api_upload(unsigned int rcmd,unsigned char *pData, unsigned char pLen);

/*
 * Description: API to upload data to Gateway
 * Parameter: null
 * Return: null
 *
 * Author: Coody.Liu
 *
 * Copyright: NexPack.Ltd
 */
unsigned char np_api_upload_to_station(unsigned int rcmd, unsigned char *pData, unsigned char pLen);

/*
 * Description: API to set a manually output address for next POST message
 * Parameter: null
 * Return: null
 *
 * Author: Coody.Liu
 *
 * Copyright: NexPack.Ltd
 */
 
void np_api_set_post_address(unsigned char address);

/*
 * Description: set auto power lpm0 mode
 * Parameter: null
 * Return: null
 *
 * Author: Coody.Liu
 *
 * Copyright: NexPack.Ltd
 */
void np_api_lpm0_automode_set(void);
/*
 * Description: clear auto power lpm0 mode
 * Parameter: null
 * Return: null
 *
 * Author: Coody.Liu
 *
 * Copyright: NexPack.Ltd
 */
void np_api_lpm0_automode_clear(void);

/*
* Description: run the loop once by wake up lpm0 once.After the loop once, software will enter lpm again.
* Parameter: null
* Return: null
*
* Author: Alan.Lin
*
* Copyright: NexPack.Ltd
*/
#define	np_api_wake_up_lpm0_once()	do{\
								 		if(np_api_lpm_mode_get() & LPM_0){np_mdk_set_run_the_loop(1);}\
							 		}while(0)


/*>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>> LPM4 function unopened, not using it >>>>>>>>>>>>>>>>>>>>>>>>>*/

/*
 * Description: set auto power lpm4 mode
 * Parameter: null
 * Return: null
 *
 * Author: Alan.Lin
 *
 * Copyright: NexPack.Ltd
 */
void np_api_lpm4_automode_set(void) ;

/*
 * Description: clear auto power lpm4 mode.
 * 				It only clear the lpm4 enable flag.That will make software never enter LPM4 again, but it can't wakeup LPM4 when software is on LPM4.
 *				It is effective when software is not on lpm4.
 *				You can use "np_api_lpm4_automode_clear_and_wakeup() " to clear the lpm4 mode and wakeup LPM4 when software on IO interrupt routines and so on .
 * Parameter: null
 * Return: null
 *
 * Author: Alan.Lin
 *
 * Copyright: NexPack.Ltd
 */				   
void np_api_lpm4_automode_clear(void);

/*
 * Description: clear auto power lpm4 mode and exit lpm4 sleep status.
 				The api is used at io interrupt for wakeup lpm4 and clear lpm4 mode.
 				The api only available within interrupt routines.
 * Parameter: null
 * Return: null
 *
 * Author: Alan.Lin
 *
 * Copyright: NexPack.Ltd
 */				   
#define np_api_lpm4_automode_clear_and_wakeup() do{\
													if (np_api_lpm_status_get() == LPM_4){\
														np_mdk_exit_lpm4_work();\
														__bic_SR_register_on_exit(LPM4_bits);\
													}\
													np_mdk_lpm4_automode_clear_flag();\
													np_mdk_start_loop_head_set();\
												  }while(0)

/*
 * Description: API to run the loop once by wake up lpm0/lpm4 once.After the loop once, software will enter lpm again.
 f				The api only available within interrupt routines.
 				If you want to exit lpm4, please using the api to wakeup lpm4 when io interrupt is comming.
 				The api also can wakeup lpm0.
 * Parameter: null
 * Return: null
 *
 * Author: Alan.Lin
 *
 * Copyright: NexPack.Ltd
 */
#define np_api_wake_up_lpm_once() do{\
									if (np_api_lpm_status_get() == LPM_4){\
										np_mdk_exit_lpm4_work();\
										__bic_SR_register_on_exit(LPM4_bits);\
									}else if(np_api_lpm_mode_get() & LPM_0){np_mdk_set_run_the_loop(1);}\
									np_mdk_start_loop_head_set();\
							      }while(0)
							     
/*
 * Description: get power status(), now software sleep at LPM_X;
 * Parameter: null
 * Return: E_LPM
 *
 * Author: Alan.Lin
 *
 * Copyright: NexPack.Ltd
 */
unsigned char np_api_lpm_status_get(void);

/*
 * Description: get the power mode, please reference "E_LPM";
 * Parameter: null
 * Return: pm mode.Such as:
 		   if only set the lpm0/lpm4 mode, return "lpm0"/"lpm4".
 		   if set the lpm0 and lpm4,  return "lpm0 | lpm4".
 * Author: Alan.Lin
 *
 * Copyright: NexPack.Ltd
 */
unsigned char np_api_lpm_mode_get(void);
				   
/******************The following API functions are not used by developer. please not used it*******************/
void np_mdk_lpm4_automode_clear_flag(void);
void np_mdk_exit_lpm4_work(void);
void np_mdk_set_run_the_loop(unsigned char t_data);
void np_mdk_start_loop_head_set(void);
/*********************************************************************************************************/

/*<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<< LPM4 function unopened, not using it <<<<<<<<<<<<<<<<<<<<<<<<<<<*/

#ifdef __cplusplus
	}
#endif

#endif /* NP_MODULE_MDK_V1_H_ */
